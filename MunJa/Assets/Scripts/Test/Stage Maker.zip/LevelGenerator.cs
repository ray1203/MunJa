using UnityEngine;

public class LevelGenerator : MonoBehaviour {

    public MapToNum[] mapToNums;
	public ColorToPrefab[] colorMappings;
    public int windowsSize;

    private int randNum;

    public int DelayNum = 0;

    public void Start()
    {
        
    }

    // Use this for initialization
    void Update()
    {
        if (DelayNum == 0)
        {
            randNum = Random.Range(0, 6) + windowsSize * 6; ;
            GenerateLevel();
        }
        //Debug.Log(realEnemyNum);
    }

	void GenerateLevel ()
	{
        for (int x = 0; x < mapToNums[randNum].map.width; x++)
        //for (int x = 0; x < mapToNums[randNum].map.width; x++)
            {
			for (int y = 0; y < mapToNums[randNum].map.height; y++)
			{
				GenerateTile(x, y);
			}
		}
	}

	void GenerateTile (int x, int y)
	{
		Color pixelColor = mapToNums[randNum].map.GetPixel(x, y);

		if (pixelColor.a == 0)
		{
			// The pixel is transparrent. Let's ignore it!
			return;
		}

		foreach (ColorToPrefab colorMapping in colorMappings)
		{
			if (colorMapping.color.Equals(pixelColor))
			{

                Vector2 position = new Vector2(x * 0.3f, y * 0.3f);
                switch (windowsSize)
                {
                    case 0:
                        position -= new Vector2(0.9f, 0.6f);
                        break;
                    case 1:
                        position -= new Vector2(1.5f, 1.2f);
                        break;
                    case 2:
                        position -= new Vector2(2.1f, 1.5f);
                        break;
                }
                Instantiate(colorMapping.prefab, position, Quaternion.identity, transform);
			}
		}
	}
	
}
