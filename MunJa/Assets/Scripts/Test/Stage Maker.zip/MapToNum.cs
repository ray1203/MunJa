﻿using UnityEngine;

[System.Serializable]
public class MapToNum
{
    public Texture2D map;
    public int EnemyNum;
    public int MapSize;
}
